package enums;

public enum Color {

	BLACK,
	WHITE;
}
