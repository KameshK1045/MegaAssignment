package enums;

public enum CRUD {

	CREATE,
	READ,
	UPDATE,
	DELETE;
}
