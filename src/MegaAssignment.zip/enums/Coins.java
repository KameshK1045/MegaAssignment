package enums;

public enum Coins {
    
	KING,
	QUEEN,
	BISHOP,
	KNIGHT,
	ROOK,
	PAWN;
}
