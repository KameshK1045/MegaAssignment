package enums;

public enum Account {
      
	SAVING,
	CREDIT,
	CHECKING_ACCOUNTS;
}
