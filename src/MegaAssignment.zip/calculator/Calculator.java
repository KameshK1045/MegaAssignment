package calculator;

public interface Calculator {
     
	public int sumOfTwoNumbers();
	public int productOfTwoNumbers();
	public double divisionOfNumbers();
	
}
