package message;

public interface Communication {
  
	public void fetchNecessaryInputs();
	public void sendMessage();
}
