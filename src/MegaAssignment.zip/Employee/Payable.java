package Employee;

public interface Payable {
     double getPaymentAmount();
}
