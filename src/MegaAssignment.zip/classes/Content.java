package classes;

public class Content {

	public void works() {
		System.out.println("writing content, tag lines");
	}
}

class Marketer extends Content{
	public void marketWork() {
		System.out.println("managing writers, marketing");
	}
}
