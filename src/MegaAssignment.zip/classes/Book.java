package classes;

public class Book {
      
	int isbn;
	int []arr = {1,2,3,4,5};
	
	
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	
	}
