package classes;

public class Designer {
 
	public void works() {
		System.out.println("designing and printing");
	}
}


class Designhead extends Designer{
	
	public void designWork() {
		System.out.println("additional responsibilities like Managing designers, Design ideation");
	}
}