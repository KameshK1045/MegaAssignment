package classes;

public abstract class RetailerShop {

	abstract void screw();
	abstract void nail();
	abstract void nuts();
	abstract void bolt();
	abstract void engline();
	
}

class Cars extends RetailerShop{

	@Override
	void screw() {
		// TODO Auto-generated method stub
		System.out.println("It has 15mm diameter");
		
	}

	@Override
	void nail() {
		// TODO Auto-generated method stub
		System.out.println("It has 50mm length");
		
	}

	@Override
	void nuts() {
		// TODO Auto-generated method stub
		System.out.println("It has 500N Threads");
		
	}

	@Override
	void bolt() {
		// TODO Auto-generated method stub
		System.out.println("It has 10mm inner dia");
		
	}

	@Override
	void engline() {
		// TODO Auto-generated method stub
		System.out.println("It has 500cc engine");
		
	}
	
}

class Lorry extends RetailerShop{

	@Override
	void screw() {
		// TODO Auto-generated method stub
		System.out.println("It has 15mm diameter");
		
	}

	@Override
	void nail() {
		// TODO Auto-generated method stub
		System.out.println("It has 50mm length");
		
	}

	@Override
	void nuts() {
		// TODO Auto-generated method stub
		System.out.println("It has 500N Threads");
		
	}

	@Override
	void bolt() {
		// TODO Auto-generated method stub
		System.out.println("It has 10mm inner dia");
		
	}

	@Override
	void engline() {
		// TODO Auto-generated method stub
		System.out.println("It has 500cc engine");
		
	}
	
}

class Tempo extends RetailerShop{

	@Override
	void screw() {
		// TODO Auto-generated method stub
		System.out.println("It has 15mm diameter");
		
	}

	@Override
	void nail() {
		// TODO Auto-generated method stub
		System.out.println("It has 50mm length");
		
	}

	@Override
	void nuts() {
		// TODO Auto-generated method stub
		System.out.println("It has 500N Threads");
		
	}

	@Override
	void bolt() {
		// TODO Auto-generated method stub
		System.out.println("It has 10mm inner dia");
		
	}

	@Override
	void engline() {
		// TODO Auto-generated method stub
		System.out.println("It has 500cc engine");
		
	}
	
}