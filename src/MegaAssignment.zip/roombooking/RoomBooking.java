package roombooking;

public interface RoomBooking {

	void fetchNecessaryInputs();
	void fetchMatchingDetails();
	void bookAndLetKnows();
}
